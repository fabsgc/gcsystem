<?php
	/**
	 * @file : sql.class.php
	 * @author : fab@c++
	 * @description : class facilitant la gestion des requêtes SQL
	 * @version : 2.2 bêta
	*/

	namespace system{
		class sql{
			use error, general;
			
			protected $_var            = array();       //liste des variables
			protected $_query          = array();       //liste des requêtes
			protected $_bdd            = array();       //connexion sql
			protected $_cache                   ;       //référence vers un objet de type cache
			protected $_requete                 ;       //contient la requête sql
			protected $_data                    ;       //contient les données
			
			const PARAM_INT                 = 1;       //les paramètres des variables, en relation avec PDO::PARAM_
			const PARAM_BOOL                = 5;
			const PARAM_NULL                = 0;
			const PARAM_STR                 = 2;
			const PARAM_FETCH               = 0;
			const PARAM_FETCHCOLUMN         = 1;
			const PARAM_FETCHINSERT         = 2;
			const PARAM_FETCHUPDATE         = 3;
			const PARAM_NORETURN            = 4;
			const PARAM_FETCHDELETE         = 5;
			
			/**
			 * Crée l'instance de la classe
			 * @access	public
			 * @return	void
			 * @param PDO : référence vers un objet de type PDO
			 * @since 2.0
			*/
			
			public  function __construct($bdd){
				$this->_bdd = $bdd;
			}
			
			/**
			 * Récupération sous la forme d'un array des variables transmises à la classe
			 * @access	public
			 * @return	void
			 * @since 2.0
			*/
			
			public function getVar(){
				return print_r($this->_var);
			}
			
			/**
			 * modification du DAO
			 * @access	public
			 * @return	void
			 * @since 2.0
			*/
			
			public function setBdd($bdd){
				$this->_bdd = $bdd;
			}
			
			/**
			 * Récupération sous la forme d'un array des requêtes sql transmises à la classe
			 * @access	public
			 * @return	void
			 * @since 2.0
			*/
			
			public function getQuery(){
				return $this->_requete;
			}
			
			/**
			 * Ajout d'une nouvelle requête SQL
			 * @access	public
			 * @return	void
			 * @param string $nom : le nom de la requête. Si vous donnez un nom existant déjà dans l'instance, l'ancienne requête sera écrasée
			 * @param string $query : Votre requête SQL avec la syntaxe de PDO (requête préparée)
			 * @param string $time : Le temps de mise en cache de la requêt
			 * @since 2.0
			*/
			
			public function query($nom, $query, $time=0){
				$this->_query[''.$nom.''] = $query;
				$this->time[''.$nom.''] = $time;
			}
			
			/**
			 * Configuration des variables à transmettre à la classe
			 * @access	public
			 * @return	void
			 * @param array $var : tableau contenant la liste des variables qui seront utilisées dans les requêtes<br />
			 *  premire syntaxe ex : array('id' => array(31, sql::PARAM_INT), 'pass' => array("fuck", sql::PARAM_STR))<br />
			 *  deuxième syntaxe ex : array('id' => 31, 'pass' => "fuck") si le type de la variable n\'est pas défini grâce aux constantes de la classe, le type sera définie directement pas la classe
			 * @since 2.0
			*/
			
			public function setVar($var = array()){
				foreach($var as $cle => $valeur){
					$this->_var[$cle] = $valeur;
				}
			}
			
			/**
			 * Exécution de la requête. Cette méthode retourne l'objet PDO juste après son exécution. (execute())
			 * @access	public
			 * @return	PDO
			 * @param string $nom : nom de la requête à exécuter
			 * @since 2.0
			*/
			
			public function execute($nom){
				try{
					$this->_requete = $this->_bdd->prepare(''.$this->_query[''.$nom.''].'');
					
					foreach($this->_var as $cle => $val){
						if(preg_match('`:'.$cle.'[\s|,|\)|\(%]`', $this->_query[''.$nom.''].' ')){
							if(is_array($val)){
								$this->_requete->bindValue($cle,$val[0],$val[1]);
							}
							else{
								switch(gettype($val)){
									case 'boolean' :
										$this->_requete->bindValue(":$cle",$val,self::PARAM_BOOL);
									break;
									
									case 'integer' :
										$this->_requete->bindValue(":$cle",$val,self::PARAM_INT);
									break;
									
									case 'double' :
										$this->_requete->bindValue(":$cle",$val,self::PARAM_STR);
									break;
									
									case 'string' :
										$this->_requete->bindValue(":$cle",$val,self::PARAM_STR);
									break;
									
									case 'NULL' :
										$this->_requete->bindValue(":$cle",$val,self::PARAM_NULL);
									break;
									
									default :
										$this->_addError('type non géré', __FILE__, __LINE__, ERROR);
									break;
								}
							}
						}
					}

					$this->_requete->execute();
					
					return $this->_requete;
				}
				catch (Exception $e) {
					$this->_addError($nom.' : '.$e->getMessage(), __FILE__, __LINE__, FATAL);
					return false;
				}
			}
			
			/**
			 * Fetch de la requête. Cette méthode retourne plusieurs valeurs en fonctions des paramètres
			 * @access	public
			 * @return	array ou boolean
			 * @param string $nom : nom de la requête à fetcher
			 * @param string $fetch : type de fetch à réaliser. Il en existe 3 :
			 *  sql::PARAM_FETCH         : correspondant au fetch de PDO. Prévu pour une requête de type SELECT
			 *  sql::PARAM_FETCHCOLUMN   : correspondant au fetchcolumn de PDO. Prévu pour une requête de type SELECT COUNT
			 *  sql::PARAM_FETCHINSERT   : Prévu pour une requête de type INSERT
			 *  sql::PARAM_FETCHUPDATE   : Prévu pour une requête de type UPDATE
			 *  sql::PARAM_FETCHDELETE   : Prévu pour une requête de type DELETE
			 *  valeur par défaut : sql::PARAM_FETCH
			 * @since 2.0
			*/

			public function fetch($nom, $fetch = self::PARAM_FETCH){
				$this->_cache = new cache($nom.'.sql', "", $this->time[''.$nom.'']);

				if($this->_cache->isDie() || $fetch == self::PARAM_FETCHINSERT){

					try {
						$this->_requete = $this->_bdd->prepare(''.$this->_query[''.$nom.''].'');
						$GLOBALS['appDev']->addSql(''.$this->_query[''.$nom.''].'');
						$this->setErrorLog(LOG_SQL, '['.$_GET['controller'].']['.$_GET['action'].']['.$nom."] \n".$this->_query[''.$nom.''].'');
						
						foreach($this->_var as $cle => $val){
							if(preg_match('`:'.$cle.'[\s|,|\)|\(%]`', $this->_query[''.$nom.''].' ')){
								if(is_array($val)){
									$this->_requete->bindValue($cle,$val[0],$val[1]);
									$GLOBALS['appDev']->addSql(' / _'.$cle.' : '.$val[0]);
									$this->setErrorLog(LOG_SQL, ':'.$cle.' : '.$val[0]);
								}
								else{
									switch(gettype($val)){
										case 'boolean' :
											$this->_requete->bindValue(":$cle",$val,self::PARAM_BOOL);
											$GLOBALS['appDev']->addSql(' / _'.$cle.' : '.$val);
											$this->setErrorLog(LOG_SQL, ':'.$cle.' : '.$val);
										break;
										
										case 'integer' :
											$this->_requete->bindValue(":$cle",$val,self::PARAM_INT);
											$GLOBALS['appDev']->addSql(' / _'.$cle.' : '.$val);
											$this->setErrorLog(LOG_SQL, ':'.$cle.' : '.$val);
										break;
										
										case 'double' :
											$this->_requete->bindValue(":$cle",$val,self::PARAM_STR);
											$GLOBALS['appDev']->addSql(' / _'.$cle.' : '.$val);
											$this->setErrorLog(LOG_SQL, ':'.$cle.' : '.$val);
										break;
										
										case 'string' :
											$this->_requete->bindValue(":$cle",$val,self::PARAM_STR);
											$GLOBALS['appDev']->addSql(' / _'.$cle.' : '.$val);
											$this->setErrorLog(LOG_SQL, ':'.$cle.' : '.$val);
										break;
										
										case 'NULL' :
											$this->_requete->bindValue(":$cle",$val,self::PARAM_NULL);
											$GLOBALS['appDev']->addSql(' / _'.$cle.' : '.$val);
											$this->setErrorLog(LOG_SQL, ':'.$cle.' : '.$val);
										break;
										
										default :
											$this->setErrorLog(LOG_SQL, 'sql, variable '.$cle.', type non géré');
										break;
									}
								}
							}
						}
						
						$GLOBALS['appDev']->addSql('####################################');
						$this->setErrorLog(LOG_SQL, "########################################################################\n\n");
						$this->_requete->execute();
						
						switch($fetch){
							case self::PARAM_FETCH : $this->_data = $this->_requete->fetchAll(); break;
							case self::PARAM_FETCHCOLUMN : $this->_data = $this->_requete->fetchColumn(); break;
							case self::PARAM_FETCHINSERT : $this->_data = true; break;
							case self::PARAM_FETCHUPDATE : $this->_data = true; break;
							case self::PARAM_FETCHDELETE : $this->_data = true; break;
							case self::PARAM_NORETURN : $this->_data = true; break;
							default : $this->setErrorLog(LOG_SQL, 'la constante d\'exécution '.$fetch.' n\'existe pas'); break;
						}
						
						switch($fetch){
							case self::PARAM_FETCH :
								$this->_cache->setVal($this->_data);
								$this->_cache->setCache($this->_data);
								return $this->_data; break;
							break;
							case self::PARAM_FETCHCOLUMN : 
								$this->_cache->setVal($this->_data);
								$this->_cache->setCache($this->_data);
								return $this->_data; 
							break;
							case self::PARAM_FETCHINSERT : return true; break;
							case self::PARAM_FETCHUPDATE : return true; break;
							case self::PARAM_FETCHDELETE : return true; break;
							case self::PARAM_NORETURN : return true; break;
							default : $this->setErrorLog(LOG_SQL, 'la constante d\'exécution '.$fetch.' n\'existe pas'); break;
						}
					} 
					catch (Exception $e) {
						$this->_addError($nom.' '.$e->getMessage(), __FILE__, __LINE__, FATAL);
						return false;
					}
				}
				else{
					return $this->_cache->getCache();
				}
			}
			
			/**
			 * Desctructeur
			 * @access	public
			 * @return	boolean
			 * @since 2.0
			*/
			
			public  function __destruct(){
			
			}
		}
	}