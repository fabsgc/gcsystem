<?php
	/**
	 * @file : picture.class.php
	 * @author : fab@c++
	 * @description : class gérant les opérations sur les images avec GD2
	 * @version : 2.2 bêta
	*/
	
	namespace helper{
	    class picture{		
			public function __construct(){
			}
			
			//resize, rotate
			
			public function __destruct(){
			}
		}
	}