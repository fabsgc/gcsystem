<?php	
	class managerIndex extends system\model{
		public function init(){
		}
	}