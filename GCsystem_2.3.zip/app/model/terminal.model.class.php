<?php	
	class managerTerminal extends system\model{
		public function init(){
		}
	}