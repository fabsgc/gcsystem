<?php
	/**
	 * @info :manager créé automatiquement par le GCsystem
	*/
	
	class managerInstalltest extends modelGc{
		protected $forms                = array();
		protected $sql                  = array();
		protected $bdd                           ;
		
		public function init(){
		}
		
		public function actionDefault(){
		}
	}