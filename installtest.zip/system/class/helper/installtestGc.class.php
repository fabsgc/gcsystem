<?php
	/**
	 * @file : installtestGc.class.php
	 * @author : fab@c++
	 * @description : class de test
	 * @version : 2.0 bêta
	*/

	class installtestGc{

		public  function __construct(){
		}

		public  function __destruct(){
		}
	}