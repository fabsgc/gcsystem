Informations :
-----------

* zip de test pour installer une class